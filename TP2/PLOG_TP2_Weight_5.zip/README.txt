--- SICStus Prolog ---
consult -> src.pl
| ?- menu.

+---------------+
| Weight solver |
+---------------+
1 - Solve Puzzle 1 (Size: 5)
2 - Solve Puzzle 2 (Size: 6)
3 - Solve Puzzle 3 (Size: 8)
4 - Solve Puzzle 4 (Size: 17)
5 - Solve Puzzle 5 (Size: 20)
-X - Solve Random Puzzle (Size: X, range: 1-40)
0 - Quit

Numeros positivos -> Puzzles pre-definidos
Numero negativo -> Gerador de puzzle de tamanho X
0 -> Sair

E necessario incluir um ponto final '.' a seguir ao numero


